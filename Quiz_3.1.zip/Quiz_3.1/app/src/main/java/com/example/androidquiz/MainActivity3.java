package com.example.androidquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    TextView textV, score;

    public void finishB(V v)
    {
        finish();

        moveTaskToBack(true);
    }

    public void newQuizB(V v)
    {
        Intent intent = getIntent();

        Intent intent3 = new Intent(this, MainActivity.class);

        intent3.putExtra("username",intent.getStringExtra("username"));

        startActivity(intent3);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        textV = findViewById(R.id.textView);
        score = findViewById(R.id.score);

        setContentView(R.layout.activity_main3);

        Intent intent2 = getIntent();
        int scores = intent2.getIntExtra("marks",0);

        String name = intent2.getStringExtra("username") ;

        score.setText(scores + "/5" );

        textV.setText("Congratulations " + name + "!" );

    }


}