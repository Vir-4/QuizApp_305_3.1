package com.example.androidquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    TextView textV3,textV4,textV5;

    int progress = 1;
    int score = 0;

    ProgressBar progressBar;

    String answer,option,choice,chance,column;
    Button b,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,submitBn,nextBn, nextbn1, nextBn2,NextBn3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent = getIntent();
        textV3.setText("Welcome " + name + "!" );
        String name = intent.getStringExtra("username");

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { answer = "one"; }
        });

        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { choice = "three";}
        });

        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { chance = "one";}
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { answer = "two"; }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { answer = "three"; }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                option = "one";
            }
        });

        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { choice = "two"; }
        });



        nextBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                textV4.setText("ANDROID QUIZ: Question 2");
                textV5.setText("Which folder you should put your images in your project ?");
                answer = null;
                submitBn.setEnabled(true);
                submitBn.setVisibility(View.VISIBLE);
                nextBn.setEnabled(false);
                nextBn.setVisibility(View.INVISIBLE);
                progressBar.setProgress((progress + 1));
                progress++;

                b1.setEnabled(false);
                b1.setVisibility(View.INVISIBLE);

                b2.setEnabled(false);
                b2.setVisibility(View.INVISIBLE);

                b3.setEnabled(false);
                b3.setVisibility(View.INVISIBLE);

                b4.setEnabled(true);
                b4.setVisibility(View.VISIBLE);

                b5.setEnabled(true);
                b5.setVisibility(View.VISIBLE);

                b6.setEnabled(true);
                b6.setVisibility(View.VISIBLE);

            }
        });

        nextButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                textView4.setText("ANDROID QUIZ: Question 3");
                textView5.setText("What should we use to display information for short period of time ?");

                option = null;
                submitBn.setEnabled(true);
                submitBn.setVisibility(View.VISIBLE);
                nextBn1.setEnabled(false);
                nextBn2.setVisibility(View.INVISIBLE);
                progressBar.setProgress((progress + 1));
                progress++;


                b4.setEnabled(false);
                b4.setVisibility(View.INVISIBLE);

                b5.setEnabled(false);
                b5.setVisibility(View.INVISIBLE);

                b6.setEnabled(false);
                b6.setVisibility(View.INVISIBLE);

                b7.setEnabled(true);
                b7.setVisibility(View.VISIBLE);
                b8.setEnabled(true);

                b8.setVisibility(View.VISIBLE);


            }
        });

        nextButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                textV4.setText("ANDROID QUIZ: Question 4");
                textV5.setText("What is Destroy() used for ?");

                choice = null;
                submitBn.setEnabled(true);
                submitBn.setVisibility(View.VISIBLE);
                nextBn2.setEnabled(false);
                nextBn2.setVisibility(View.INVISIBLE);
                progressBar.setProgress((progress + 1));
                progress++;

                b7.setEnabled(false);
                b7.setVisibility(View.INVISIBLE);

                b8.setEnabled(false);
                b8.setVisibility(View.INVISIBLE);

                b9.setEnabled(false);
                b9.setVisibility(View.INVISIBLE);

                b10.setEnabled(true);
                b10.setVisibility(View.VISIBLE);

                b11.setEnabled(true);
                b11.setVisibility(View.VISIBLE);

                b12.setEnabled(true);
                b12.setVisibility(View.VISIBLE);

            }
        });

        submitBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(answer == "one")
                {
                    b1.setBackgroundColor(Color.RED);
                    b3.setBackgroundColor(Color.GREEN);

                }
                else if(answer == "three")
                {
                    b3.setBackgroundColor(Color.GREEN);
                    score++;
                }

                else if(option == "three") {
                    b4.setBackgroundColor(Color.GREEN);
                    b6.setBackgroundColor(Color.RED);
                    submitBn.setEnabled(false);

                    submitBn.setVisibility(View.INVISIBLE);
                    nextB1.setEnabled(true);

                    nextB1.setVisibility(View.VISIBLE);
                }
                else if(chance == "one") {

                    submitBn.setEnabled(false);
                    submitBn.setVisibility(View.INVISIBLE);

                    b11.setBackgroundColor(Color.GREEN);
                    b10.setBackgroundColor(Color.RED);

                }

                else if(chance == "two")
                {
                    b11.setBackgroundColor(Color.GREEN);
                    submitBn.setEnabled(false);

                    submitBn3.setVisibility(View.INVISIBLE);
                    nextBn3.setEnabled(true);

                    nextBn3.setVisibility(View.VISIBLE);
                    score++;
                }

                else if(choice == "one") {

                    submiBn.setVisibility(View.INVISIBLE);
                    nextBn2.setEnabled(true);
                    nextBn2.setVisibility(View.VISIBLE);

                    b8.setBackgroundColor(Color.GREEN);

                    b7.setBackgroundColor(Color.RED);
                    submitBn.setEnabled(false);


                }

                else if(choice == "two")
                {
                    b8.setBackgroundColor(Color.GREEN);
                    submitBn.setEnabled(false);

                    submitBn.setVisibility(View.INVISIBLE);

                    nextBn2.setEnabled(true);
                    nextBn2.setVisibility(View.VISIBLE);

                    score++;
                }
                else if(answer == "two")
                {
                    b2.setBackgroundColor(Color.RED);
                    b3.setBackgroundColor(Color.GREEN);

                }


                else if(choice == "three") {
                    b8.setBackgroundColor(Color.GREEN);
                    b9.setBackgroundColor(Color.RED);

                    submitBn.setEnabled(false);
                    submitBn.setVisibility(View.INVISIBLE);

                    nextBn2.setEnabled(true);
                    nextBn2.setVisibility(View.VISIBLE);
                }


                else if(column == "three") {
                    b15.setBackgroundColor(Color.GREEN);
                    submitBn.setEnabled(false);
                    submitBn.setVisibility(View.INVISIBLE);
                    nextBn4.setEnabled(true);
                    nextBn4.setVisibility(View.VISIBLE);
                    score++;

                }

                else if(column == "two")
                {
                    b15.setBackgroundColor(Color.GREEN);
                    b14.setBackgroundColor(Color.RED);

                    submitBn.setEnabled(false);

                    submitBn.setVisibility(View.INVISIBLE);
                    nextBn.setEnabled(true);
                    nextBn4.setVisibility(View.VISIBLE);

                }
                else
                {
                    Toast.makeText( MainActivity2.this ,  "Please select an option first",Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    public void NextButton(View view)
    {
        Intent intent = getIntent();
        Intent intent2 = new Intent(this, MainActivity3.class);

        intent2.putExtra("marks",score);
        intent2.putExtra("username",intent.getStringExtra("username"));

        startActivity(intent2);

    }
}